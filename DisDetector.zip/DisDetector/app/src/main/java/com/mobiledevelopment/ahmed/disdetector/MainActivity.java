package com.mobiledevelopment.ahmed.disdetector;

import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    private ProgressBar progressBar;
    private TextView output;
    private EditText inputEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        /*Create progressBar and set its visibility*/
        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        progressBar.setVisibility(View.GONE);
        inputEditText = (EditText) findViewById(R.id.termToAnalyze);
        output = (TextView) findViewById(R.id.results);
        /*We used "new" so that it can point to a different
        * point in memory, in case if there's another string
        * that is set to "NO INPUT"*/
    }

    public void search (View v) {
        Uri builtUri2 = Uri.parse("https://api.meaningcloud.com/sentiment-2.1").buildUpon()
                .appendQueryParameter("key","5cefecfee765dde6c9c943db4c891c88")
                .appendQueryParameter("txt",inputEditText.getText().toString())
                .appendQueryParameter("lang","en")
                .build();

        /*We will create an anonymous instance and call our AsyncTask, which will
        * explicitly start doInBackground when we execute. Do this after we create
        * the FindSentimentTask method below. We made this anonymous because we're
        * not going to use this instance again. Anonymous means we can't refer to it
        * again.*/
        new FindSentimentTask().execute(builtUri2.toString());

    }

    /*When we extend a class, we have to Override its abstract methods (Ex. doInBackground).
    * So you click ALT ENTER and choose implement methods to override doInBackground*/
    public class FindSentimentTask extends AsyncTask<String, Void, String>
    {

        @Override
        protected String doInBackground(String... url) {
            /*... means that it can have a String array, one String, or multiple Strings.
            * Changed second parameter to url.*/

            String toReturn= "DID NOT WORK";
            try
            {
                toReturn=getResponseFromHttpUrl(url[0]);

            }catch (Exception e)
            {
                Log.d("ErrorInApp","exception on get Response from HTTP call" + e.getMessage());
                /*Redo the quotations for "ErrorInApp" if it's still red*/
                return toReturn;
                /*toReturn is the argument for onPostExecute*/
            }


            return toReturn;
        }
        protected void onPostExecute(String sentimentData) {
            /*P+: strong positive
            P: positive
            NEU: neutral
            N: negative
            N+: strong negative
            NONE: without sentiment*/
            try {
                JSONObject sentimentJSON = new JSONObject(sentimentData);
                //int x=5;
                //output.setText(sentimentJSON.toString());
                //JSONObject status= sentimentJSON.getJSONObject("model");
                String scoreTag = sentimentJSON.get("score_tag").toString();
                String confidence = sentimentJSON.get("confidence").toString();
                String irony = sentimentJSON.get("irony").toString();

                if (scoreTag.contains("P+"))
                {
                    scoreTag = "strong positive";
                }
                else if (scoreTag.contains("P"))
                {
                    scoreTag = "positive";
                }
                else if (scoreTag.contains("NONE"))
                {
                    scoreTag = "without sentiment";
                }
                else if (scoreTag.contains("NEU"))
                {
                    scoreTag = "neutral";
                }
                else if (scoreTag.contains("N+"))
                {
                    scoreTag = "strong negative";
                }
                else if (scoreTag.contains("N"))
                {
                    scoreTag = "negative";
                }

                if(irony.contains("NONIRONIC"))
                {
                    irony = "not ironic";
                }
                else {irony = "ironic";}

                output.setText("The statement is " + scoreTag + ".\n" + "It was also " + irony + ".\nWe are " + confidence + "% confident about that.\n");

            } catch (JSONException e) {
                e.printStackTrace();
            } /*There was a missing bracket when I put the catch statement here.*/
        }
    }

    public static String getResponseFromHttpUrl(String url) throws IOException {
        URL theURL= new URL(url);
        HttpURLConnection urlConnection = (HttpURLConnection) theURL.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            urlConnection.disconnect();
        }
    }/*end getResponse bracket that was missing from the slide copy-paste*/

}/*end main*/